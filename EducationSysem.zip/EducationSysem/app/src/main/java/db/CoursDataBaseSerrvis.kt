package db

import modul.*

interface CoursDataBaseSerrvis{
    fun InsertCourse(course: Course)
    fun InsertStudent(student: Student)
    fun getAllCourse():List<Course>
    fun getAllStudens():List<Student>
    fun getByIdCourse(id:Int):Course
    fun getByIdStudent(id: Int):Student
    fun deleteCourse(course: Course)
    fun deleteStudent(student: Student)
    fun updateCourse(course: Course):Int
    fun updateStudent(student: Student):Int

    fun InsertMentor(mentors: Mentor)
    fun getAllMentor():List<Mentor>
    fun deleteMentor(mentors: Mentor)
    fun updateMentor(mentors: Mentor):Int
    fun getBtIdMentor(id:Int): Mentor

    fun Insertguruh(gruhList: GruhList)
    fun getAllGuruh():List<GruhList>
    fun update(gruhList: GruhList):Int
    fun getGuruhById(id:Int): GruhList
    fun newGuruhDelete(gruhList: GruhList)

    fun InsertNewStudent(newStudentAdd: NewStudentAdd)
    fun getAllNewStudent():List<NewStudentAdd>
    fun updateNewStudent(newStudentAdd: NewStudentAdd):Int
    fun getnewStudentById(id:Int): NewStudentAdd
    fun newStudentDelete(newStudentAdd: NewStudentAdd)

}