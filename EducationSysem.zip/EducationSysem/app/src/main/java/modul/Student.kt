package modul

class Student {
    var studentId:String?=null
    var studentName:String?=null
    var studentLastName:String?=null
    var fathersName:String?=null
    var data:String?=null
    var mentors:String?=null
    var groups:String?=null
    var courseName:String? = null



    constructor()
    constructor(
        studentId: String,
        studentName: String?,
        studentLastName: String?,
        fathersName: String?,
        data: String?,
        mentors: String?,
        groups: String?,
        courseName:String?
    ) {
        this.studentId = studentId
        this.studentName = studentName
        this.studentLastName = studentLastName
        this.fathersName = fathersName
        this.data = data
        this.mentors = mentors
        this.groups = groups
        this.courseName = courseName
    }
}