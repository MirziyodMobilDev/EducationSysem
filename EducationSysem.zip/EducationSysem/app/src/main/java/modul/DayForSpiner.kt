package modul

 data class DayForSpiner(var dayName:String)