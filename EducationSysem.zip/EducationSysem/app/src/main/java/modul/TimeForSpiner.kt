package modul

data class TimeForSpiner(var timeName:String)