package modul

class GroupForSpiner(var groupName:String)