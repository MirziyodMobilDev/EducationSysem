package com.example.educationsysem

import Adapters.MentorSpiner
import Adapters.NewGroupAdapter
import Adapters.TimeSpiner
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import db.CourseDatabaseHelper
import kotlinx.android.synthetic.main.activity_add_new_group.*
import kotlinx.android.synthetic.main.activity_add_new_group.view.*
import kotlinx.android.synthetic.main.fragment_new_group_add.view.*
import kotlinx.android.synthetic.main.item_open_group_dialog.*
import kotlinx.android.synthetic.main.item_open_group_dialog.view.*
import modul.GruhList
import modul.Mentor
import modul.TimeForSpiner


class NewGroupAddFragment : Fragment() {
    lateinit var newGroupAdapter: NewGroupAdapter
    lateinit var list:ArrayList<GruhList>
    lateinit var listt:ArrayList<GruhList>
    lateinit var courseDatabaseHelper: CourseDatabaseHelper
    lateinit var mentorList:ArrayList<Mentor>
    lateinit var timeList:ArrayList<TimeForSpiner>
    lateinit var root:View



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        courseDatabaseHelper = CourseDatabaseHelper(container?.context!!)
        root = inflater.inflate(R.layout.fragment_new_group_add, container, false)
        list = ArrayList()
        listt = ArrayList()
        list = courseDatabaseHelper.getAllGuruh()
//        Log.d(TAG, "onCreateView: ")

        newGroupAdapter = NewGroupAdapter(list,object :NewGroupAdapter.OnClickListener{
            override fun editClick(gruhList: GruhList, position: Int) {
                var aletrtDialog = AlertDialog.Builder(this@NewGroupAddFragment.context)
                aletrtDialog.setView(R.layout.item_open_group_dialog)
               var dialog = aletrtDialog.show()


                dialog.add_course_name.setText(gruhList.gruhName)
                dialog.edit_group.setOnClickListener{
                    var name =  dialog.add_course_name.text.toString()
                    var mentor= mentorList[dialog.open_add_mentor_dialog.selectedItemPosition].mentorName
                    var time = timeList[dialog.open_add_data_dialog.selectedItemPosition].timeName
                    var gruhList = GruhList(name,mentor,time)

                    courseDatabaseHelper.update(gruhList)
                    list[position]= gruhList
                    newGroupAdapter.notifyItemChanged(position)
                    dialog.dismiss()
                }


            }

            override fun deleteClick(gruhList: GruhList, position: Int) {
             courseDatabaseHelper.newGuruhDelete(gruhList)
                list.remove(gruhList)
                newGroupAdapter.notifyItemRemoved(position)
                newGroupAdapter.notifyItemRangeChanged(position,list.size)
            }

            override fun viewClick(gruhList: GruhList, position: Int) {
               var intent = Intent(this@NewGroupAddFragment.context,AllStudentList::class.java)
                val bundle = Bundle()
                bundle.putSerializable("guruh",gruhList)
                intent.putExtras(bundle)
                startActivity(intent)
            }
        })
        return root

    }


    override fun onResume() {
        newGroupAdapter.notifyDataSetChanged()
        newGroupAdapter.notifyItemChanged(list.size)
        root.rv_new.adapter = newGroupAdapter
        super.onResume()
    }

}