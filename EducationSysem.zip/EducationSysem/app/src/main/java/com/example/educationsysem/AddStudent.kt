package com.example.educationsysem

import Adapters.GroupSpinner
import Adapters.MentorSpiner
import Kusrsconstant.Constant
import android.app.DatePickerDialog
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.annotation.RequiresApi
import db.CourseDatabaseHelper
import kotlinx.android.synthetic.main.activity_add_student.*
import modul.GroupForSpiner
import modul.Mentor
import modul.Student

class AddStudent : AppCompatActivity() {
    lateinit var courseDatabaseHelper: CourseDatabaseHelper
    lateinit var mentorSpiner: MentorSpiner
    lateinit var groupSpiner: GroupSpinner
    lateinit var mList:ArrayList<Mentor>
    lateinit var mListt:ArrayList<Mentor>
    lateinit var gList:ArrayList<GroupForSpiner>
    lateinit var datta:String
    lateinit var intentName:String
    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_student)
        courseDatabaseHelper = CourseDatabaseHelper(this)

        calendar.setOnClickListener {
            var datePicker = DatePickerDialog(this)
            datePicker.setOnDateSetListener{datePicker,i1,i2,i3 ->
                datta = "$i1/$i2/$i3"
                edit_calendar.setText(datta)

            }
            datePicker.show()
        }

        intentName = intent.getStringExtra("name").toString()
        mList = ArrayList()
        mListt = ArrayList()
        var mList = courseDatabaseHelper.getAllMentor()

        for(i in 0 until mList.size){
            if(mList[i].courseName == intentName){
                mListt.add(mList[i])
            }
        }
        mentorSpiner = MentorSpiner(mListt)
        mentor_spinner.adapter = mentorSpiner



        Student_saqlash_btn.setOnClickListener {
            var surnamee =  surname.text.toString()
            var nameee = name.text.toString()
            var middle_namee =  middle_name.text.toString()
            var mentor =mentor_spinner.selectedItem.toString()
            var group = gList[group_spinner.selectedItemPosition].groupName
            if (surnamee.isNotBlank()&&surnamee.isNotBlank()&&nameee.isNotBlank()&&middle_namee.isNotBlank()&&mentor.isNotBlank()&&group.isNotBlank()&&datta.isNotBlank()){
            var student = Student(Constant.STUDENT_ID,surnamee,nameee,middle_namee,datta,mentor,group,intentName)
            courseDatabaseHelper.InsertStudent(student)
            finish()
        }else{
                Toast.makeText(this,"malumotlar to'liq kiritimadi", Toast.LENGTH_LONG).show()

        }
        }

        orqaga.setOnClickListener {
            finish()
        }



    }

}