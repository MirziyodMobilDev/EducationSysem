package com.example.educationsysem

import Adapters.NewGroupAdapter
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.fragment_new_group_add.view.*
import kotlinx.android.synthetic.main.fragment_opened.view.*
import modul.GruhList


class OpenedFragment : Fragment() {
    lateinit var newGroupAdapter: NewGroupAdapter
    lateinit var list:ArrayList<GruhList>
    lateinit var root:View

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        list=ArrayList()
       root = inflater.inflate(R.layout.fragment_opened, container, false)
        newGroupAdapter = NewGroupAdapter(list,object :NewGroupAdapter.OnClickListener{
            override fun editClick(gruhList: GruhList, position: Int) {
                var aletrtDialog = AlertDialog.Builder(this@OpenedFragment.context)
                aletrtDialog.setView(R.layout.item_open_group_dialog)
                aletrtDialog.show()
            }

            override fun deleteClick(gruhList: GruhList, position: Int) {
                TODO("Not yet implemented")
            }

            override fun viewClick(gruhList: GruhList, position: Int) {
                var intent = Intent(this@OpenedFragment.context,AllStudentList::class.java)
                startActivity(intent)
            }
        })
        root.rv_eski.adapter =newGroupAdapter
        newGroupAdapter.notifyDataSetChanged()
        return root

    }


}