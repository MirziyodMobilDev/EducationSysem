package Adapters

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.example.educationsysem.NewGroupAddFragment
import com.example.educationsysem.OpenedFragment

class ViewPegerAdapter( var title:ArrayList<String>,  fragmentManager: FragmentManager): FragmentStatePagerAdapter(fragmentManager,
    BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
    ) {
    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {
        return when(position){
            0 ->{
               return OpenedFragment()
            }

           1 -> {
               return NewGroupAddFragment()
            }
            else ->{
                return Fragment()
            }
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return title[position]
    }
}